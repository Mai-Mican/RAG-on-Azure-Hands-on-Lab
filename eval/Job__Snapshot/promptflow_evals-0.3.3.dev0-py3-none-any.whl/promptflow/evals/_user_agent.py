# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from promptflow.evals._version import VERSION

USER_AGENT = "{}/{}".format("promptflow-evals", VERSION)
